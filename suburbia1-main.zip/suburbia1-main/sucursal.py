from views.sucursal_view import SucursalView

if __name__ == "__main__":
    app = SucursalView()
    app.mainloop()