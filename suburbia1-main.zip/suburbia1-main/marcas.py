from views.marcas_view import VentanaMarcas

if __name__ == "__main__":
    app = VentanaMarcas()
    app.mainloop()