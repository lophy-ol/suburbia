from views.metodo_pago_view import MetodoPagoView
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = MetodoPagoView(root)
    root.mainloop()